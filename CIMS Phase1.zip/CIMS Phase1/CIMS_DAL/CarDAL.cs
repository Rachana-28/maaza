﻿using CIMS_Entities;
using CIMS_Exceptions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace CIMS_DAL
{
    public class CarDAL
    {
        public static string FileName = @"Cars";
        public List<Car> objCars = new List<Car>();
        public bool AddCarDAL(Car objCar)
        {
            bool carAdded;
            try
            {
                objCars.Add(objCar);
                Serialization();
                carAdded = true;
            }
            catch(CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carAdded ;
        }
        public bool UpdateCarDAL(Car objCar)
        {
            Deserialization();
            bool carUpdated = false;
            try
            {
                Car objcar = objCars.Find(c=>c.Model==objCar.Model);
                if(objcar!=null)
                {
                    objcar.ManufacturerName = objCar.ManufacturerName;
                    objcar.Model = objCar.Model;
                    objcar.Type = objCar.Type;
                    objcar.Engine = objCar.Engine;
                    objcar.BHP = objCar.BHP;
                    objcar.Transmission = objCar.Transmission;
                    objcar.Mileage = objCar.Mileage;
                    objcar.Seats = objCar.Seats;
                    objcar.AirBagDetails = objCar.AirBagDetails;
                    objcar.BootSpace = objCar.BootSpace;
                    objcar.Colour = objCar.Colour;
                    objcar.Price = objCar.Price;
                }                
                carUpdated = true;
                Serialization();
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carUpdated;
        }
        public bool DeleteCarDAL(string model)
        {
            Deserialization();
            bool carDeleted = false;
            try
            {
                Car objcar = objCars.Find(c => c.Model == model);
                if (objcar != null)
                {
                    objCars.Remove(objcar);
                    carDeleted = true;
                    Serialization();
                }
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carDeleted;
        }
        //public List<Car> SearchCarByNameDAL(string Name)
        //{
        //    Deserialization();
        //    try
        //    {              
        //        return objCars;
        //    }
        //    catch (CIMSException objCIMSEx)
        //    {
        //        throw objCIMSEx;
        //    }
        //    catch (Exception objEx)
        //    {
        //        throw objEx;
        //    }
        //}
        public Car SearchCarByModelDAL(string model)
        {
            Deserialization();
            try
            {
                Car objCar = objCars.Find(c => c.Model == model);
                return objCar;
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        public List<Car> GetListDAL()
        {
            Deserialization();
            try
            {
                //List<Car> objcars = objCars.FindAll(c => c == objCar);
                return objCars;
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        public void Serialization()
        {
            try
            {
                FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, objCars);
                fs.Close();
                //Carlist.Clear();
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        public void Deserialization()
        {
            try
            {
                FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                //Carlist.Clear();
                objCars = bf.Deserialize(fs) as List<Car>;
                fs.Close();
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }

        }
    }
}
